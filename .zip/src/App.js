import React from 'react'
import Home from "./components/home";

const App = () => {
  return (
    <Home/>
  )
}

export default App;